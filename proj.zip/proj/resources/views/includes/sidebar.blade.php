<ul class="sidebar navbar-nav">
	<li class="nav-item active">
		<a class="nav-link" href="{{ url('/') }}">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>User List</span>
		</a>
	</li>
	@if(Auth::user()->role->name=="Admin")
	<li class="nav-item active">
		<a class="nav-link" href="{{ url('user-roles') }}">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>User Roles</span>
		</a>
	</li>
	@endif
</ul>