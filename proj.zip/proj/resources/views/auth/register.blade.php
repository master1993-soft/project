@extends('layouts.app')

@section('content')
<body>

    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Register an Account</div>
        <div class="card-body">
           <div id="error"></div>
            <div class="output_results"></div>
            <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" id="form">
                 {{ csrf_field() }}
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" class="form-control" name="firstname" placeholder="First name" autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" class="form-control" name="lastname" placeholder="Last name">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="email" id="email" class="form-control" name="email" placeholder="Email address">
                    <label for="email">Email address</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="number" id="mobile" class="form-control" name="mobile" placeholder="Mobile number">
                    <label for="mobile">Mobile number</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="col-md-12">
                    <div class="form-label-group">
                      <input type="file" id="photo" class="form-control" name="photo">
                      <label for="photo">Select Photo</label>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <br>
                    <div class="form-label-group">
                      <select id="role" class="form-control" name="role">
                        <option value="">Select Role</option>
                        @if(!empty($roles))
                          @foreach($roles as $dt)
                          <option value="{{$dt->id}}">{{$dt->name}}</option>
                          @endforeach
                        @endif
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 text-center">
                  <img id="blah" src="images/default-user-image.png" style="width:100px; height:100px; border:1px solid #ddd" alt="your image" />
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" id="password" class="form-control" name="password" placeholder="Password"/>
                    <label for="password">Password</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" id="password-confirm" class="form-control" name="password_confirmation" placeholder="Confirm password" />
                    <label for="password-confirm">Confirm password</label>
                  </div>
                </div>
              </div>
            </div>
            <button type="button" class="btn btn-primary btn-block" id="ap_submit">Register</button>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="{{ url('/login') }}">Login Page</a>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('script')
    <script>
     $("#ap_submit").click(function(e){
        
        var formdata=new FormData($("#form")[0]);

        $.ajax({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
            },
            url:"/register",
            type:"post",
            data:formdata,
            processData:false,
            dataType: "json",
            contentType:false,
            cache:false,
            success:function (data){
                if(data.status==1){
                    //alert(data.msg);
                    $("#error").html("<div class='alert alert-success alert-xs'>"+data.msg+"</div>");
                    document.getElementById("form").reset();
                }else{
                    printErrorMsg (data.msg);
                }
            }
        });
     });

    function printErrorMsg (msg) {
        msg=msg+" ";
        var msg1=msg.split(',');
        $("#error").find("ul").html('');
        $("#error").css('display','block');
        var out="<div  class='alert alert-danger alert-xs'><ul style='margin:0px;'>";
        for (i = 0; i < msg1.length; i++) {
          out+="<li>" + msg1[i] + "</li>";
        }
        $("#error").html(out+"</ul></div>");
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#photo").change(function(){
        readURL(this);
    });
    </script>
@endsection
