@extends('layouts.app')

@section('content')
<body>

    <div class="container">
      <div class="card mx-auto">
        <div class="card-header">Update Profile</div>
        <div class="card-body">
           <div id="error"></div>
            <div class="output_results"></div>
            <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" id="form">
                 {{ csrf_field() }}
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" class="form-control"  value="{{$user->firstname}}"  name="firstname" placeholder="First name" autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" class="form-control" value="{{$user->lastname}}" name="lastname" placeholder="Last name">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="email" id="email" class="form-control" readonly="true" value="{{$user->email}}" name="email" placeholder="Email address">
                    <label for="email">Email address</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="number" id="mobile" class="form-control" value="{{$user->mobile}}" name="mobile" placeholder="Mobile number">
                    <label for="mobile">Mobile number</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="col-md-12">
                    <div class="form-label-group">
                      <input type="file" id="photo" class="form-control" name="photo">
                      <label for="photo">Update Photo</label>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <br>
                    <div class="form-label-group">
                      <select id="role" class="form-control" name="role">
                        <option value="">Select Role</option>
                        @if(!empty($roles))
                          @foreach($roles as $dt)
                          <option value="{{$dt->id}}" @if($user->role->name==$dt->name) selected @endif >{{$dt->name}}</option>
                          @endforeach
                        @endif
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 text-center">
                  <img id="blah" src="{{$user->photo}}" style="width:100px; height:100px; border:1px solid #ddd" alt="your image" />
                </div>
              </div>
            </div>
         
            <button type="button" class="btn btn-primary btn-block col-md-1" id="ap_submit">Update</button>
          </form>
        </div>
      </div>
    </div>

@endsection

@section('script')
    <script>
     $("#ap_submit").click(function(e){
        
        var formdata=new FormData($("#form")[0]);

        $.ajax({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
            },
            url:"/updateprofile",
            type:"post",
            data:formdata,
            processData:false,
            dataType: "json",
            contentType:false,
            cache:false,
            success:function (data){
                if(data.status==1){
                    //alert(data.msg);
                    $("#error").html("<div class='alert alert-success alert-xs'>"+data.msg+"</div>");
                    document.getElementById("form").reset();
                    window.location.reload();
                }else{
                    printErrorMsg (data.msg);
                }
            }
        });
     });

    function printErrorMsg (msg) {
        msg=msg+" ";
        var msg1=msg.split(',');
        $("#error").find("ul").html('');
        $("#error").css('display','block');
        var out="<div  class='alert alert-danger alert-xs'><ul style='margin:0px;'>";
        for (i = 0; i < msg1.length; i++) {
          out+="<li>" + msg1[i] + "</li>";
        }
        $("#error").html(out+"</ul></div>");
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#photo").change(function(){
        readURL(this);
    });
    </script>
@endsection
