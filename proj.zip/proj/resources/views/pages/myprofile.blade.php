@extends('layouts.app')

@section('content')
<body>

    <div class="container">
      <div class="card mx-auto">
        <div class="card-header">My Profile <a href="{{ url('profile-edit') }}" class="btn btn-info btn-sm pull-right">Edit Profile</a></div>
        <div class="card-body">
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" readonly="true" class="form-control" name="firstname" placeholder="First name" value="{{$user->firstname}}">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" class="form-control" name="lastname" value="{{$user->lastname}}" readonly="true" placeholder="Last name">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="email" id="email" class="form-control" name="email" value="{{$user->email}}" readonly="true" placeholder="Email address">
                    <label for="email">Email address</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="number" id="mobile" value="{{$user->mobile}}" readonly="true" class="form-control" name="mobile" placeholder="Mobile number">
                    <label for="mobile">Mobile number</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                    <div class="form-label-group">
                      <input type="text" id="mobile" value="{{$user->role->name}}" readonly="true" class="form-control" name="mobile" placeholder="Mobile number">
                      <label for="mobile">User Role</label>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                  <img id="blah" src="{{$user->photo}}" style="width:100px; height:100px; border:1px solid #ddd" alt="your image" />
                </div>
              </div>
            </div>
           
        </div>
      </div>
    </div>

@endsection
