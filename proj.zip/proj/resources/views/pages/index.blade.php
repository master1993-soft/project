@extends('layouts.app')
@section('content')
<div class="container-fluid">
	
	<div class="card mb-3">
		<div class="card-header"><i class="fas fa-table"></i>Registered Users List</div>
		<div class="card-body">
			<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                  <thead>
                    <tr>
                      <th>Full name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Role</th>
                      <th>Photo</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
				@if(!empty($users))
                  @foreach($users as $dt)
                    <tr>
                      <th>{{$dt->firstname}} {{$dt->lastname}}</th>
                      <th>{{$dt->email}}</th>
                      <th>{{$dt->mobile}}</th>
                      <th>{{$dt->role->name}}</th>
                      <th>
                      	<img src="{{$dt->photo}}" width="50px">
                      </th>
                      <th>
                      	@if($dt->role->name=="User" && Auth::user()->role->name=="Admin")
                      	<form action="deleteuser" method="POST" onsubmit="return confirm('Are you sure?');">
                      		 {{ csrf_field() }}
                      		<input type="hidden" name="userid" value="{{$dt->id}}">
	                    	<button class="btn btn-danger btn-sm">Delete</button>
	                    </form>
	                    @endif
                      </th>
                    </tr>
                  @endforeach
				@endif
				</tbody>
              </table>
		</div>
	</div>
</div>
@stop