@extends('layouts.app')
@section('content')
<div class="container-fluid">
	
	<div class="card mb-3">
		<div class="card-header"><i class="fas fa-table"></i> Roles List</div>
		<div class="card-body">
			<div class="col-md-6">
			<div class="flash-message">
	            @foreach (['danger', 'warning', 'success', 'info'] as $msg)
	              @if(Session::has('alert-' . $msg))
	              <p class="alert alert-{{ $msg }} text-left"><i class="fa fa-thumbs-up"></i> {{ Session::get('alert-' . $msg) }}</p>
	              @endif
	            @endforeach
	         </div>
				<form method="POST" action="user-roles">
	                 {{ csrf_field() }}
		            <div class="form-group">
		              <div class="form-row">
		                <div class="col-md-6">
		                  <div class="form-label-group">
		                    <select class="form-control" name="role" required="true">
		                    	<option value="Admin">Admin</option>
		                    	<option value="User">User</option>
		                    </select>
		                  </div><br>
		                  <button type="submit" class="btn btn-primary btn-block">Submit</button>
		                </div>
		              </div>
		            </div>

		        </form>
			</div>
			<div class="col-md-6">
				<div class="table-responsive">
	                <table class="table table-bordered" width="100%" cellspacing="0">
	                  <thead>
	                    <tr>
	                      <th>Role Name</th>
	                    </tr>
	                  </thead>
	                  <tbody>
						@if(!empty($roles))
		                  @foreach($roles as $dt)
		                    <tr>
		                      <th>{{$dt->name}}</th>
		                    </tr>
		                  @endforeach
						@endif
					</tbody>
	              </table>
				</div>
			</div>
	</div>
</div>
@stop