<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Auth::routes();

Route::group(['middleware' => 'auth'], function () {

	Route::get('/','UserController@UserData');
	Route::get('/user-roles','UserController@UserRoles');
	Route::POST('/deleteuser','UserController@deleteUser');
	Route::POST('/user-roles','UserController@addRole');
	Route::get('/myprofile','UserController@UserProfile');
	Route::get('/profile-edit','UserController@editProfile');
	Route::POST('/updateprofile','UserController@updateUser');

});