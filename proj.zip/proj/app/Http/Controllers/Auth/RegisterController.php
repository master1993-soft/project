<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Auth\Events\Registered;
use Mail;




class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */

    public function register(Request $request)
    {

        $vaild =   Validator::make($request->all(), [
            'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'mobile' => 'required|numeric|digits:10',
            'photo' => 'required|mimes:jpeg,bmp,png',
            'role' => 'required',
            'password' => 'required|min:6|confirmed',
        ]);

        if ($vaild->fails()) {
            return response()->json(["status"=>0,'msg'=>$vaild->errors()->all()]);
        }else{

            $user=new User();
            $user->firstname=$request->input("firstname");
            $user->lastname=$request->input("lastname");
            $user->email=$request->input("email");
            $user->mobile=$request->input("mobile");
            $photo=$request->file("photo");
            $user->password=$request->input("password");
            $user->role_id=$request->input("role");
            $image_name=time().".".$photo->getClientOriginalExtension();
            $destinationpath= public_path("/images");
            $photo->move($destinationpath,$image_name);
            $user->photo="images/".$image_name;
           // $user->save();

            $name=$request->input("firstname");
            $tom=$request->input("email");
            
            try{

            }
            catch(\Swift_TransportException $e){
                $this->sendmail($name,$tom,"Test mail");
            }
            
            return response()->json(["status"=>1,'msg'=>"New User Added Successfully!"]);
        }
    }

    public function sendmail($name,$tomail,$msg){
       
        $data['title'] = "This is Test Mail Tuts Make";
 
        Mail::send('mail', $data, function($message) use($name,$tomail) {
 
            $message->to($tomail, $name)->subject('Verify OTF Coder Account');
        });
 
        if (Mail::failures()) {
           return response()->Fail('Sorry! Please try again latter');
         }else{
           return response()->success('Great! Successfully send in your mail');
         }
    }



    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'email' => $data['email'],
            'mobile' => $data['mobile'],
            'photo' => $data['photo'],
            'password' => bcrypt($data['password']),
        ]);
    }



}
