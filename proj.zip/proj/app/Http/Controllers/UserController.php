<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Roles;
use Session;
use Auth;
use Illuminate\Support\Facades\Validator;
class UserController extends Controller
{   
    public function UserData()
    {
        $user=\App\User::with('role')->where('status',1)->get();
        return view('pages.index')->with('users', $user);
    }

    public function deleteUser(Request $req){
        $id=$req->input("userid");
        $user=\App\User::where('id',$id)->delete();
        return $this->UserData();
    }

    public function UserRoles()
    {
        $roles=\App\Roles::all();
        return view('pages.user-roles')->with('roles', $roles);
    }

    public function addRole(Request $req){
        try{
            $rolename=$req->input("role");
            $role=new Roles();
            $role->name=$rolename;
            $role->save();
            Session::flash('alert-success', 'Role added.');
        }catch(\Illuminate\Database\QueryException $ex){
            Session::flash('alert-danger', 'Role Already added.');
        }
        return redirect('user-roles');
    }

    public function UserProfile(){
        $uid= Auth::user()->id;
        $user=\App\User::find($uid);
        return view('pages.myprofile')->with('user', $user);
    }

    public function editProfile(){
        $uid= Auth::user()->id;
        $user=\App\User::find($uid);
        $roles=\App\Roles::all();
        return view('pages.profile-edit',['user' => $user,"roles" => $roles]);
    }
    public function updateUser(Request $request)
    {

        $vaild =   Validator::make($request->all(), [
            'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'mobile' => 'required|numeric|digits:10',
            'role' => 'required',
        ]);

        if ($vaild->fails()) {
            return response()->json(["status"=>0,'msg'=>$vaild->errors()->all()]);
        }else{
            $uid= Auth::user()->id;
            $user=\App\User::find($uid);
            $user->firstname=$request->input("firstname");
            $user->lastname=$request->input("lastname");
            $user->email=$request->input("email");
            $user->mobile=$request->input("mobile");
            $photo=$request->file("photo");
            $user->role_id=$request->input("role");
            if(!empty($photo)){
                $image_name=time().".".$photo->getClientOriginalExtension();
                $destinationpath= public_path("/images");
                $photo->move($destinationpath,$image_name);
                $user->photo="images/".$image_name;
            }
            $user->save();

            return response()->json(["status"=>1,'msg'=>"User Profile Updated Successfully!"]);
        }
    }
}
