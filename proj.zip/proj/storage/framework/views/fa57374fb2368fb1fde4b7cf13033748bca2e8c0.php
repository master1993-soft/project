<?php $__env->startSection('content'); ?>
<body>

    <div class="container">
      <div class="card mx-auto">
        <div class="card-header">Update Profile</div>
        <div class="card-body">
           <div id="error"></div>
            <div class="output_results"></div>
            <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" id="form">
                 <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="firstName" class="form-control"  value="<?php echo e($user->firstname); ?>"  name="firstname" placeholder="First name" autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" class="form-control" value="<?php echo e($user->lastname); ?>" name="lastname" placeholder="Last name">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="email" id="email" class="form-control" readonly="true" value="<?php echo e($user->email); ?>" name="email" placeholder="Email address">
                    <label for="email">Email address</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="number" id="mobile" class="form-control" value="<?php echo e($user->mobile); ?>" name="mobile" placeholder="Mobile number">
                    <label for="mobile">Mobile number</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="col-md-12">
                    <div class="form-label-group">
                      <input type="file" id="photo" class="form-control" name="photo">
                      <label for="photo">Update Photo</label>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <br>
                    <div class="form-label-group">
                      <select id="role" class="form-control" name="role">
                        <option value="">Select Role</option>
                        <?php if(!empty($roles)): ?>
                          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($dt->id); ?>" <?php if($user->role->name==$dt->name): ?> selected <?php endif; ?> ><?php echo e($dt->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 text-center">
                  <img id="blah" src="<?php echo e($user->photo); ?>" style="width:100px; height:100px; border:1px solid #ddd" alt="your image" />
                </div>
              </div>
            </div>
         
            <button type="button" class="btn btn-primary btn-block col-md-1" id="ap_submit">Update</button>
          </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
     $("#ap_submit").click(function(e){
        
        var formdata=new FormData($("#form")[0]);

        $.ajax({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
            },
            url:"/updateprofile",
            type:"post",
            data:formdata,
            processData:false,
            dataType: "json",
            contentType:false,
            cache:false,
            success:function (data){
                if(data.status==1){
                    //alert(data.msg);
                    $("#error").html("<div class='alert alert-success alert-xs'>"+data.msg+"</div>");
                    document.getElementById("form").reset();
                    window.location.reload();
                }else{
                    printErrorMsg (data.msg);
                }
            }
        });
     });

    function printErrorMsg (msg) {
        msg=msg+" ";
        var msg1=msg.split(',');
        $("#error").find("ul").html('');
        $("#error").css('display','block');
        var out="<div  class='alert alert-danger alert-xs'><ul style='margin:0px;'>";
        for (i = 0; i < msg1.length; i++) {
          out+="<li>" + msg1[i] + "</li>";
        }
        $("#error").html(out+"</ul></div>");
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#photo").change(function(){
        readURL(this);
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>