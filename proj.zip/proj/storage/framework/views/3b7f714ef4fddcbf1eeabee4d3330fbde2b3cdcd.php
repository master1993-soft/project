<div>
  <?php echo e($title); ?>

</div>