<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	
	<div class="card mb-3">
		<div class="card-header"><i class="fas fa-table"></i> Roles List</div>
		<div class="card-body">
			<div class="col-md-6">
			<div class="flash-message">
	            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	              <?php if(Session::has('alert-' . $msg)): ?>
	              <p class="alert alert-<?php echo e($msg); ?> text-left"><i class="fa fa-thumbs-up"></i> <?php echo e(Session::get('alert-' . $msg)); ?></p>
	              <?php endif; ?>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         </div>
				<form method="POST" action="user-roles">
	                 <?php echo e(csrf_field()); ?>

		            <div class="form-group">
		              <div class="form-row">
		                <div class="col-md-6">
		                  <div class="form-label-group">
		                    <select class="form-control" name="role" required="true">
		                    	<option value="Admin">Admin</option>
		                    	<option value="User">User</option>
		                    </select>
		                  </div><br>
		                  <button type="submit" class="btn btn-primary btn-block">Submit</button>
		                </div>
		              </div>
		            </div>

		        </form>
			</div>
			<div class="col-md-6">
				<div class="table-responsive">
	                <table class="table table-bordered" width="100%" cellspacing="0">
	                  <thead>
	                    <tr>
	                      <th>Role Name</th>
	                    </tr>
	                  </thead>
	                  <tbody>
						<?php if(!empty($roles)): ?>
		                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <tr>
		                      <th><?php echo e($dt->name); ?></th>
		                    </tr>
		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</tbody>
	              </table>
				</div>
			</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>