<!-- Sticky Footer -->
<footer class="sticky-footer" style="width: 100%;">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright © OTFCoder <?php echo e(date('Y')); ?></span>
    </div>
  </div>
</footer>