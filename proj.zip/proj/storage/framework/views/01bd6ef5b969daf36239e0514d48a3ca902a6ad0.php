<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	
	<div class="card mb-3">
		<div class="card-header"><i class="fas fa-table"></i>Registered Users List</div>
		<div class="card-body">
			<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                  <thead>
                    <tr>
                      <th>Full name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Role</th>
                      <th>Photo</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
				<?php if(!empty($users)): ?>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th><?php echo e($dt->firstname); ?> <?php echo e($dt->lastname); ?></th>
                      <th><?php echo e($dt->email); ?></th>
                      <th><?php echo e($dt->mobile); ?></th>
                      <th><?php echo e($dt->role->name); ?></th>
                      <th>
                      	<img src="<?php echo e($dt->photo); ?>" width="50px">
                      </th>
                      <th>
                      	<?php if($dt->role->name=="User" && Auth::user()->role->name=="Admin"): ?>
                      	<form action="deleteuser" method="POST" onsubmit="return confirm('Are you sure?');">
                      		 <?php echo e(csrf_field()); ?>

                      		<input type="hidden" name="userid" value="<?php echo e($dt->id); ?>">
	                    	<button class="btn btn-danger btn-sm">Delete</button>
	                    </form>
	                    <?php endif; ?>
                      </th>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</tbody>
              </table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>