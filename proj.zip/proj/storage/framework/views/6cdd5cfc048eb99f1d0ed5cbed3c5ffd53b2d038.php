<ul class="sidebar navbar-nav">
	<li class="nav-item active">
		<a class="nav-link" href="<?php echo e(url('/')); ?>">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>User List</span>
		</a>
	</li>
	<?php if(Auth::user()->role->name=="Admin"): ?>
	<li class="nav-item active">
		<a class="nav-link" href="<?php echo e(url('user-roles')); ?>">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>User Roles</span>
		</a>
	</li>
	<?php endif; ?>
</ul>