<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$faker = Faker\Factory::create();
    	for ($i=0; $i < 1000; $i++) {
	        DB::table('users')->insert([
	            'firstname' => $faker->firstNameMale,
	            'lastname' => $faker->firstNameMale,
	            'email' => Str::random(10).'@gmail.com',
	            'mobile' => $faker->phoneNumber,
	            'password' => Hash::make('password'),
	            'role_id' => 2, // if role id is 2 then their name must be User instead Admin
	            'status' => 1,
	            'photo' => $faker->imageUrl($width = 200, $height = 200)
	        ]);
	    }
    }
}
